import React from 'react';
import { Users } from 'lucide-react';

const doctors = [
  {
    name: 'Dr. Snap MacIntosh',
    specialty: 'General Dentist',
    appointments: 4,
    available: true,
  },
  {
    name: 'Dr. Jerald O\'Hara',
    specialty: 'Orthodontist',
    appointments: 3,
    available: true,
  },
  {
    name: 'Dr. Putri Larasati',
    specialty: 'Periodontist',
    appointments: 5,
    available: false,
  },
  {
    name: 'Dr. Emma Chen',
    specialty: 'Endodontist',
    appointments: 2,
    available: true,
  },
];

const DoctorsList = () => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="p-4 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-gray-500" />
          <h3 className="font-medium">Available Doctors</h3>
        </div>
      </div>
      <div className="p-4">
        <div className="space-y-4">
          {doctors.map((doctor) => (
            <div key={doctor.name} className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gray-200 flex-shrink-0"></div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {doctor.name}
                </p>
                <p className="text-xs text-gray-500">
                  {doctor.specialty} • {doctor.appointments} appointments
                </p>
              </div>
              <div className={`w-2 h-2 rounded-full ${doctor.available ? 'bg-green-400' : 'bg-gray-300'}`}></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DoctorsList;