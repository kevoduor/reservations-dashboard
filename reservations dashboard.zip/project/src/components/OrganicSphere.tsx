import React, { useEffect, useRef } from 'react';

const OrganicSphere = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: Array<{
      x: number;
      y: number;
      radius: number;
      color: string;
      speed: number;
      angle: number;
    }> = [];

    const colors = ['#38bdf8', '#0ea5e9', '#0284c7'];
    const PARTICLE_COUNT = 50;
    const CENTER_X = canvas.width / 2;
    const CENTER_Y = canvas.height / 2;
    const RADIUS = 20;

    // Initialize particles
    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const angle = (Math.PI * 2 * i) / PARTICLE_COUNT;
      particles.push({
        x: CENTER_X + Math.cos(angle) * RADIUS,
        y: CENTER_Y + Math.sin(angle) * RADIUS,
        radius: Math.random() * 2 + 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        speed: 0.02,
        angle,
      });
    }

    const animate = () => {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach((particle) => {
        particle.angle += particle.speed;
        particle.x = CENTER_X + Math.cos(particle.angle) * RADIUS;
        particle.y = CENTER_Y + Math.sin(particle.angle) * RADIUS;

        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
        ctx.fillStyle = particle.color;
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      width={60}
      height={60}
      className="opacity-80"
    />
  );
};

export default OrganicSphere;