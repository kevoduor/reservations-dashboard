import React from 'react';
import { Calendar as CalendarIcon, Clock, Users, Search, Plus, Filter } from 'lucide-react';
import AppointmentCalendar from './AppointmentCalendar';
import DoctorsList from './DoctorsList';

const ReservationsView = () => {
  return (
    <div className="p-6 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Reservations</h1>
          <p className="text-sm text-gray-500">Manage your clinic's appointments</p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search for anything..."
              className="pl-10 pr-4 py-2 w-64 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
            <Plus className="w-4 h-4" />
            New Appointment
          </button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-9">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between p-4 border-b border-gray-100">
              <div className="flex items-center gap-4">
                <button className="px-4 py-2 text-sm font-medium text-gray-900 bg-gray-100 rounded-lg">
                  Calendar
                </button>
                <button className="px-4 py-2 text-sm font-medium text-gray-500 hover:text-gray-900">
                  Log History
                </button>
              </div>
              <div className="flex items-center gap-3">
                <button className="flex items-center gap-2 px-3 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg">
                  <Filter className="w-4 h-4" />
                  Filters
                </button>
                <select className="px-3 py-2 text-sm text-gray-600 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option>Day</option>
                  <option>Week</option>
                  <option>Month</option>
                </select>
              </div>
            </div>
            <AppointmentCalendar />
          </div>
        </div>

        <div className="col-span-3">
          <DoctorsList />
        </div>
      </div>
    </div>
  );
};

export default ReservationsView;