import React from 'react';
import { ChevronLeft, ChevronRight, Clock } from 'lucide-react';
import { Appointment, appointmentColors } from '../config/appointments';

const appointments: Appointment[] = [
  {
    id: 1,
    patient: 'Beth Johnson',
    time: '10:00 AM',
    duration: '1h',
    type: 'general-checkup',
    status: 'completed',
    color: 'pink'
  },
  {
    id: 2,
    patient: 'Steve Neville',
    time: '11:30 AM',
    duration: '1h',
    type: 'scaling',
    status: 'completed',
    color: 'green'
  },
  {
    id: 3,
    patient: 'Andreas Pats',
    time: '1:00 PM',
    duration: '1h',
    type: 'bleaching',
    status: 'in-progress',
    color: 'blue'
  },
  {
    id: 4,
    patient: 'Leonard Singh',
    time: '2:30 PM',
    duration: '2h',
    type: 'deep-treatment',
    status: 'scheduled',
    color: 'purple'
  }
];

const AppointmentCard = ({ appointment }: { appointment: Appointment }) => {
  const colors = appointmentColors[appointment.type];
  
  return (
    <div
      style={{
        backgroundColor: colors.bg,
        borderColor: colors.border,
      }}
      className="p-3 rounded-lg border transition-all hover:shadow-md cursor-pointer"
    >
      <div className="flex items-center justify-between mb-1">
        <span className="text-sm font-medium" style={{ color: colors.text }}>
          {appointment.patient}
        </span>
        <div className="flex items-center gap-1">
          <Clock className="w-3 h-3 text-gray-400" />
          <span className="text-xs text-gray-500">{appointment.time}</span>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500 capitalize">
          {appointment.type.replace('-', ' ')}
        </span>
        <span 
          className="text-[10px] px-2 py-0.5 rounded-full"
          style={{
            backgroundColor: colors.border,
            color: colors.text
          }}
        >
          {appointment.duration}
        </span>
      </div>
    </div>
  );
};

const AppointmentCalendar = () => {
  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <h2 className="text-lg font-semibold">Today</h2>
          <div className="flex items-center gap-2">
            <button className="p-1 rounded-lg hover:bg-gray-100">
              <ChevronLeft className="w-5 h-5 text-gray-500" />
            </button>
            <button className="p-1 rounded-lg hover:bg-gray-100">
              <ChevronRight className="w-5 h-5 text-gray-500" />
            </button>
          </div>
        </div>
        <div className="text-sm text-gray-500">
          Fri, 16 May 2022
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {['Dr. Snap MacIntosh', 'Dr. Jerald O\'Hara', 'Dr. Putri Larasati', 'Dr. Emma Chen'].map((doctor, index) => (
          <div key={doctor} className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gray-200"></div>
                <span className="text-sm font-medium">{doctor}</span>
              </div>
            </div>
            <div className="space-y-2">
              {appointments.filter((_, i) => i === index).map((appointment) => (
                <AppointmentCard key={appointment.id} appointment={appointment} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AppointmentCalendar;